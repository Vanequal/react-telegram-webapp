import React from 'react';
import '../styles/components/state-components.scss';

const EmptyState = () => (
  <p className="empty-state">
    Идей пока нет
  </p>
);

export default EmptyState;