import React from 'react';

const LoadingState = () => (
  <div className="loading-state">
    <p>Загрузка...</p>
  </div>
);

export default LoadingState;